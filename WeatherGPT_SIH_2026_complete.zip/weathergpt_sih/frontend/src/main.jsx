import React, {useEffect, useMemo, useRef, useState} from "react";
import {createRoot} from "react-dom/client";
import {Bot, CloudRain, MapPin, Mic, Send, ShieldAlert, Sparkles, Sun, Wind, Leaf, Plane, Siren, Info, ChevronRight} from "lucide-react";
import {AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer} from "recharts";
import "./style.css";

const API = "http://localhost:8000/api";

function App(){
  const [location,setLocation]=useState({name:"Jaipur",lat:26.9124,lon:75.7873,state:"Rajasthan"});
  const [weather,setWeather]=useState(null);
  const [messages,setMessages]=useState([{role:"assistant",text:"Hi! I’m WeatherGPT. Ask me about weather, rain, travel risk, farming, or disaster alerts."}]);
  const [input,setInput]=useState("");
  const [lang,setLang]=useState("en");
  const [mode,setMode]=useState("general");
  const [loading,setLoading]=useState(false);
  const [showEvidence,setShowEvidence]=useState(false);
  const [listening,setListening]=useState(false);
  const recognition=useRef(null);

  async function loadWeather(loc=location){
    const r=await fetch(`${API}/weather?lat=${loc.lat}&lon=${loc.lon}`);
    const d=await r.json(); setWeather(d);
  }
  useEffect(()=>{loadWeather()},[]);

  async function send(text=input){
    if(!text.trim() || loading) return;
    setInput(""); setMessages(m=>[...m,{role:"user",text}]); setLoading(true);
    try{
      const r=await fetch(`${API}/chat`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
        message:text,language:lang,mode,lat:location.lat,lon:location.lon,location_name:location.name
      })});
      const d=await r.json();
      setMessages(m=>[...m,{role:"assistant",text:d.answer,data:d}]); setWeather({current:d.weather.current,daily:d.weather.daily,risk:d.risk});
    }catch(e){setMessages(m=>[...m,{role:"assistant",text:"Backend is not reachable. Start FastAPI on port 8000."}])}
    setLoading(false);
  }

  function voice(){
    const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!SR){alert("Voice input is not supported in this browser.");return}
    if(listening){recognition.current?.stop();return}
    const r=new SR(); recognition.current=r; r.lang=lang==="hi"?"hi-IN":"en-IN"; r.interimResults=false;
    r.onstart=()=>setListening(true); r.onend=()=>setListening(false);
    r.onresult=e=>setInput(e.results[0][0].transcript); r.start();
  }

  const chart=useMemo(()=>weather?.daily?.time?.slice(0,7).map((d,i)=>({
    day:new Date(d).toLocaleDateString("en-IN",{weekday:"short"}),
    max:weather.daily.temperature_2m_max[i], rain:weather.daily.precipitation_probability_max[i]
  }))||[],[weather]);

  const risk=weather?.risk;
  return <div className="app">
    <aside className="sidebar">
      <div className="brand"><div className="brandIcon"><Sparkles size={21}/></div><div><b>WeatherGPT</b><small>AI Weather Intelligence</small></div></div>
      <div className="sideTitle">ADVISORY MODES</div>
      {[
        ["general","General","Ask anything","☁️"],
        ["agriculture","Agriculture","Crop decisions","🌾"],
        ["travel","Travel","Route conditions","✈️"],
        ["disaster","Disaster","Early warning","🚨"]
      ].map(x=><button key={x[0]} className={"mode "+(mode===x[0]?"active":"")} onClick={()=>setMode(x[0])}><span>{x[3]}</span><div><b>{x[1]}</b><small>{x[2]}</small></div><ChevronRight size={15}/></button>)}
      <div className="sideCard"><ShieldAlert size={18}/><div><b>Safety first</b><p>Critical decisions should use official IMD/local authority warnings.</p></div></div>
      <div className="sideBottom"><span>SIH 2026 Prototype</span><span className="dot"></span><span>Live AI</span></div>
    </aside>

    <main>
      <header>
        <div><span className="eyebrow">CONVERSATIONAL WEATHER INTELLIGENCE</span><h1>Understand the sky.<br/><em>Act before the risk.</em></h1></div>
        <div className="headerTools">
          <select value={lang} onChange={e=>setLang(e.target.value)}><option value="en">English</option><option value="hi">हिन्दी</option></select>
          <button className="locationBtn" onClick={()=>loadWeather()}><MapPin size={16}/>{location.name}</button>
        </div>
      </header>

      <section className="heroGrid">
        <div className="chatCard">
          <div className="cardTop"><div className="aiBadge"><Bot size={16}/> AI ORCHESTRATOR</div><button onClick={()=>setShowEvidence(!showEvidence)} className="evidenceBtn"><Info size={14}/> Why this answer?</button></div>
          <div className="messages">
            {messages.map((m,i)=><div className={"msg "+m.role} key={i}><div className="avatar">{m.role==="assistant"?<Bot size={15}/>: "V"}</div><div><div className="bubble">{m.text}</div>{m.data&&<div className="miniEvidence"><span>✓ Forecast data</span><span>✓ Risk engine</span><span>✓ Source trace</span></div>}</div></div>)}
            {loading&&<div className="msg assistant"><div className="avatar"><Bot size={15}/></div><div className="bubble typing">WeatherGPT is checking the forecast…</div></div>}
          </div>
          <div className="quick">
            {["Will it rain tomorrow?","Is it safe to travel?","Should I irrigate today?","Any severe weather?"].map(q=><button key={q} onClick={()=>send(q)}>{q}</button>)}
          </div>
          <div className="composer"><button className={listening?"mic listening":""} onClick={voice}><Mic size={19}/></button><input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&send()} placeholder="Ask WeatherGPT in natural language…"/><button className="send" onClick={()=>send()}><Send size={18}/></button></div>
        </div>

        <div className="weatherPanel">
          <div className="locationLine"><MapPin size={15}/>{location.name}, {location.state}<span>•</span><span>Now</span></div>
          {weather?<><div className="temp">{Math.round(weather.current.temperature_2m)}°<span>C</span></div><div className="condition">{weather.daily? "Forecast intelligence active":"Loading…"}</div>
          <div className="metrics"><Metric icon={<CloudRain/>} label="Rain" value={weather.daily?.precipitation_probability_max?.[0]+"%"} /><Metric icon={<Wind/>} label="Wind" value={Math.round(weather.current.wind_speed_10m)+" km/h"}/><Metric icon={<Sun/>} label="Feels" value={Math.round(weather.current.apparent_temperature)+"°C"}/></div>
          <div className={"risk "+risk?.level.toLowerCase()}><div><ShieldAlert size={18}/><div><b>{risk?.level} RISK</b><small>Decision-support signal</small></div></div><strong>{risk?.score}/100</strong></div>
          </>:<div className="loader">Loading live weather…</div>}
        </div>
      </section>

      <section className="lowerGrid">
        <div className="panel forecast"><div className="panelHead"><div><span className="eyebrow">7-DAY OUTLOOK</span><h2>Forecast intelligence</h2></div><span className="sourcePill">DATA FEED</span></div>
          <div className="chart"><ResponsiveContainer width="100%" height={190}><AreaChart data={chart}><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopOpacity=".28"/><stop offset="100%" stopOpacity=".02"/></linearGradient></defs><XAxis dataKey="day" axisLine={false} tickLine={false}/><YAxis hide/><Tooltip/><Area type="monotone" dataKey="max" strokeWidth={2} fill="url(#g)" /></AreaChart></ResponsiveContainer></div>
          <div className="forecastRow">{chart.slice(0,5).map((x,i)=><div key={i}><b>{x.day}</b><span>{Math.round(x.max)}°</span><small>💧 {x.rain}%</small></div>)}</div>
        </div>
        <div className="panel actions"><div className="panelHead"><div><span className="eyebrow">DECISION SUPPORT</span><h2>What should I do?</h2></div></div>
          {[
            [<Leaf/>,"Agriculture","Plan irrigation & spraying","agriculture"],
            [<Plane/>,"Travel","Check weather risk","travel"],
            [<Siren/>,"Disaster","Monitor warnings","disaster"]
          ].map((x,i)=><button key={i} onClick={()=>setMode(x[3])}><div className="actionIcon">{x[0]}</div><div><b>{x[1]}</b><small>{x[2]}</small></div><ChevronRight/></button>)}
        </div>
      </section>

      {showEvidence&&<div className="evidenceModal" onClick={()=>setShowEvidence(false)}><div className="evidenceBox" onClick={e=>e.stopPropagation()}><div className="cardTop"><h2>Why this answer?</h2><button onClick={()=>setShowEvidence(false)}>×</button></div><p>WeatherGPT separates data retrieval from AI generation. The AI receives structured weather values instead of inventing them.</p>{["Current weather feed","7-day forecast feed","Transparent risk rules","Official IMD/WIS2 integration hook"].map((x,i)=><div className="proof" key={x}><span>0{i+1}</span><b>{x}</b><small>{i===3?"Use authorized IMD/WIS2 data in the SIH production deployment.":"Used as evidence before the answer is generated."}</small></div>)}</div></div>}
    </main>
  </div>
}
function Metric({icon,label,value}){return <div className="metric"><span>{icon}</span><small>{label}</small><b>{value}</b></div>}
createRoot(document.getElementById("root")).render(<App/>)
