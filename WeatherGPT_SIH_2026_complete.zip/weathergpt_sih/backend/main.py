import os
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

load_dotenv()

app = FastAPI(title="WeatherGPT API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

LLM_PROVIDER = os.getenv("LLM_PROVIDER", "groq")
LLM_API_KEY = os.getenv("LLM_API_KEY", "")
LLM_MODEL = os.getenv("LLM_MODEL", "llama-3.3-70b-versatile")
LLM_BASE_URL = os.getenv("LLM_BASE_URL", "https://api.groq.com/openai/v1")
IMD_BASE_URL = os.getenv("IMD_BASE_URL", "")
IMD_API_KEY = os.getenv("IMD_API_KEY", "")

CITY_DB = {
    "jaipur": {"name": "Jaipur", "state": "Rajasthan", "lat": 26.9124, "lon": 75.7873},
    "delhi": {"name": "Delhi", "state": "Delhi", "lat": 28.6139, "lon": 77.2090},
    "mumbai": {"name": "Mumbai", "state": "Maharashtra", "lat": 19.0760, "lon": 72.8777},
    "kota": {"name": "Kota", "state": "Rajasthan", "lat": 25.2138, "lon": 75.8648},
    "jodhpur": {"name": "Jodhpur", "state": "Rajasthan", "lat": 26.2389, "lon": 73.0243},
    "udaipur": {"name": "Udaipur", "state": "Rajasthan", "lat": 24.5854, "lon": 73.7125},
    "ahmedabad": {"name": "Ahmedabad", "state": "Gujarat", "lat": 23.0225, "lon": 72.5714},
    "lucknow": {"name": "Lucknow", "state": "Uttar Pradesh", "lat": 26.8467, "lon": 80.9462},
    "kolkata": {"name": "Kolkata", "state": "West Bengal", "lat": 22.5726, "lon": 88.3639},
    "chennai": {"name": "Chennai", "state": "Tamil Nadu", "lat": 13.0827, "lon": 80.2707},
    "bengaluru": {"name": "Bengaluru", "state": "Karnataka", "lat": 12.9716, "lon": 77.5946},
    "hyderabad": {"name": "Hyderabad", "state": "Telangana", "lat": 17.3850, "lon": 78.4867},
}

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=1000)
    language: str = "en"
    lat: Optional[float] = None
    lon: Optional[float] = None
    location_name: Optional[str] = None
    mode: str = "general"

class ChatResponse(BaseModel):
    answer: str
    location: Dict[str, Any]
    weather: Dict[str, Any]
    risk: Dict[str, Any]
    evidence: List[Dict[str, str]]
    actions: List[str]
    generated_by: str

def find_city(text: str):
    low = text.lower()
    for key, value in CITY_DB.items():
        if key in low:
            return value
    return None

async def geocode_city(name: str):
    url = "https://geocoding-api.open-meteo.com/v1/search"
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(url, params={"name": name, "count": 1, "language": "en", "format": "json"})
        r.raise_for_status()
        data = r.json()
    if not data.get("results"):
        return None
    x = data["results"][0]
    return {"name": x.get("name"), "state": x.get("admin1", ""), "lat": x["latitude"], "lon": x["longitude"]}

async def get_weather(lat: float, lon: float):
    # Development provider. Replace with authorized IMD calls for SIH production.
    url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude": lat, "longitude": lon,
        "current": "temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,rain,weather_code,wind_speed_10m,wind_gusts_10m,visibility",
        "hourly": "temperature_2m,precipitation_probability,precipitation,rain,wind_speed_10m,weather_code",
        "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,sunrise,sunset",
        "timezone": "auto", "forecast_days": 7
    }
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.get(url, params=params)
        r.raise_for_status()
        return r.json()

def code_to_text(code: int) -> str:
    mapping = {
        0:"Clear",1:"Mainly clear",2:"Partly cloudy",3:"Overcast",
        45:"Fog",48:"Rime fog",51:"Light drizzle",53:"Drizzle",55:"Heavy drizzle",
        61:"Light rain",63:"Moderate rain",65:"Heavy rain",
        71:"Light snow",73:"Snow",75:"Heavy snow",80:"Rain showers",
        81:"Rain showers",82:"Heavy rain showers",95:"Thunderstorm",
        96:"Thunderstorm with hail",99:"Severe thunderstorm"
    }
    return mapping.get(code, "Unknown")

def calculate_risk(w: Dict[str, Any]) -> Dict[str, Any]:
    c = w["current"]
    rain_prob = max(w["daily"]["precipitation_probability_max"][:2] or [0])
    rain_sum = max(w["daily"]["precipitation_sum"][:2] or [0])
    gust = c.get("wind_gusts_10m") or 0
    code = c.get("weather_code", 0)
    score = 0
    reasons = []

    if rain_prob >= 80: score += 35; reasons.append("High precipitation probability")
    elif rain_prob >= 50: score += 20; reasons.append("Moderate precipitation probability")
    if rain_sum >= 50: score += 35; reasons.append("Potentially heavy accumulated rainfall")
    elif rain_sum >= 20: score += 20; reasons.append("Meaningful rainfall expected")
    if gust >= 50: score += 20; reasons.append("Strong wind gusts")
    if code in (95,96,99): score += 30; reasons.append("Thunderstorm signal")

    if score >= 70: level = "HIGH"
    elif score >= 40: level = "MODERATE"
    else: level = "LOW"

    return {"level": level, "score": min(score,100), "reasons": reasons or ["No major hazard signal in the development forecast"]}

def make_actions(mode: str, risk: Dict[str, Any], language: str) -> List[str]:
    high = risk["level"] == "HIGH"
    if language.startswith("hi"):
        if mode == "agriculture":
            return ["बारिश के दौरान छिड़काव से बचें।", "सिंचाई से पहले अगले forecast window की जाँच करें।"] if high else ["मौसम देखकर सिंचाई/छिड़काव का समय तय करें।"]
        if mode == "disaster":
            return ["स्थानीय आधिकारिक चेतावनी को प्राथमिकता दें।", "निचले इलाकों और जलभराव वाले रास्तों से बचें।"] if high else ["आधिकारिक चेतावनियों पर नज़र रखें।"]
        return ["बाहर जाने से पहले forecast और official alerts देखें।"]
    if mode == "agriculture":
        return ["Avoid spraying during expected rain.", "Recheck the next forecast window before irrigation."] if high else ["Use the forecast window to plan irrigation or spraying."]
    if mode == "disaster":
        return ["Prioritize official IMD/local authority alerts.", "Avoid low-lying or waterlogged areas if heavy rain develops."] if high else ["Keep monitoring official warnings."]
    if mode == "travel":
        return ["Check the forecast immediately before departure.", "Allow extra travel time if rain or thunderstorms intensify."]
    return ["Check official alerts before acting on severe-weather information."]

def local_answer(req: ChatRequest, location: Dict[str, Any], weather: Dict[str, Any], risk: Dict[str, Any]):
    d = weather["daily"]
    temp = weather["current"]["temperature_2m"]
    unit = weather["current_units"].get("temperature_2m", "°C")
    tomorrow_prob = d["precipitation_probability_max"][1]
    tomorrow_rain = d["precipitation_sum"][1]
    condition = code_to_text(d["weather_code"][0])
    if req.language.startswith("hi"):
        return (f"{location['name']} में अभी {temp}{unit} और स्थिति {condition} है। "
                f"अगले दिन बारिश की संभावना लगभग {tomorrow_prob}% और अनुमानित वर्षा {tomorrow_rain} mm है। "
                f"जोखिम स्तर {risk['level']} है। गंभीर निर्णयों के लिए आधिकारिक IMD चेतावनी को प्राथमिकता दें।")
    return (f"In {location['name']}, the current temperature is {temp}{unit} with {condition} conditions. "
            f"For tomorrow, precipitation probability is about {tomorrow_prob}% with an estimated {tomorrow_rain} mm of rain. "
            f"The development risk level is {risk['level']}. For critical decisions, prioritize official IMD warnings.")

async def ai_answer(req: ChatRequest, location: Dict[str, Any], weather: Dict[str, Any], risk: Dict[str, Any]):
    if not LLM_API_KEY:
        return local_answer(req, location, weather, risk), "local evidence engine"

    system = """You are WeatherGPT, a safety-focused meteorological assistant.
Never invent weather values. Use ONLY the supplied weather JSON.
Explain uncertainty clearly. For severe weather, tell the user to prioritize official government/IMD warnings.
Return a concise, useful answer in the requested language.
The user may be a farmer, traveler, citizen, or disaster manager.
Do not claim the development provider is IMD."""
    payload = {
        "location": location,
        "current": weather["current"],
        "daily": {k: v[:3] for k,v in weather["daily"].items() if isinstance(v, list)},
        "risk": risk,
        "mode": req.mode,
        "user_question": req.message,
        "language": req.language
    }
    headers = {"Authorization": f"Bearer {LLM_API_KEY}", "Content-Type": "application/json"}
    body = {
        "model": LLM_MODEL,
        "temperature": 0.2,
        "messages": [{"role":"system","content":system},
                     {"role":"user","content":str(payload)}]
    }
    try:
        async with httpx.AsyncClient(timeout=25) as client:
            r = await client.post(f"{LLM_BASE_URL.rstrip('/')}/chat/completions", headers=headers, json=body)
            r.raise_for_status()
            answer = r.json()["choices"][0]["message"]["content"]
            return answer, f"{LLM_PROVIDER} + evidence engine"
    except Exception:
        return local_answer(req, location, weather, risk), "local evidence engine (AI fallback)"

@app.get("/api/health")
async def health():
    return {"status":"ok","service":"WeatherGPT"}

@app.get("/api/location")
async def location(q: str):
    city = find_city(q) or await geocode_city(q)
    if not city:
        raise HTTPException(404, "Location not found")
    return city

@app.get("/api/weather")
async def weather(lat: float, lon: float):
    data = await get_weather(lat, lon)
    return {
        "current": data["current"],
        "current_units": data["current_units"],
        "daily": data["daily"],
        "risk": calculate_risk(data),
        "source": "Open-Meteo development provider; replace/augment with authorized IMD integration"
    }

@app.post("/api/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    loc = None
    if req.lat is not None and req.lon is not None:
        loc = {"name": req.location_name or "Selected location", "state": "", "lat": req.lat, "lon": req.lon}
    else:
        loc = find_city(req.message)
        if not loc and req.location_name:
            loc = await geocode_city(req.location_name)
        if not loc:
            # Common Hindi city mentions
            aliases = {"जयपुर":"Jaipur","दिल्ली":"Delhi","मुंबई":"Mumbai","कोटा":"Kota","जोधपुर":"Jodhpur"}
            for hi, en in aliases.items():
                if hi in req.message:
                    loc = CITY_DB[en.lower()]
                    break
        if not loc:
            loc = CITY_DB["jaipur"]

    data = await get_weather(loc["lat"], loc["lon"])
    risk = calculate_risk(data)
    answer, engine = await ai_answer(req, loc, data, risk)
    tomorrow = {
        "date": data["daily"]["time"][1],
        "min": data["daily"]["temperature_2m_min"][1],
        "max": data["daily"]["temperature_2m_max"][1],
        "rain_probability": data["daily"]["precipitation_probability_max"][1],
        "rain_mm": data["daily"]["precipitation_sum"][1],
        "condition": code_to_text(data["daily"]["weather_code"][1])
    }
    evidence = [
        {"label":"Current observation", "value": "Live weather provider response"},
        {"label":"Forecast", "value": "7-day numerical forecast feed"},
        {"label":"Risk engine", "value": "Transparent rule-based risk layer"},
        {"label":"Official-source note", "value": "For SIH deployment, connect authorized IMD APIs/WIS2 feeds"}
    ]
    return ChatResponse(
        answer=answer, location=loc,
        weather={"current":data["current"],"tomorrow":tomorrow,"daily":data["daily"]},
        risk=risk, evidence=evidence,
        actions=make_actions(req.mode, risk, req.language),
        generated_by=engine
    )

@app.get("/api/alerts")
async def alerts():
    # Demo alert layer. In SIH production, populate from authorized IMD/WIS2 CAP alerts.
    return {
        "alerts": [
            {"id":"demo-1","severity":"WATCH","title":"Weather monitoring active","location":"Rajasthan","text":"Demo alert layer. Connect official IMD/WIS2 CAP alerts for live dissemination."}
        ],
        "source":"Demo alert layer"
    }
