# WeatherGPT — SIH 2026 Prototype

AI-powered conversational weather intelligence platform for the Smart India Hackathon.

## Features
- AI weather chatbot with tool/function-style weather retrieval
- Current weather + 7-day forecast
- Location search
- Risk/advisory engine
- Agriculture, travel and disaster advisory modes
- Hindi/English responses
- Alert dashboard
- Interactive forecast charts
- "Why this answer?" source/evidence panel
- Voice input using browser Web Speech API
- IMD adapter hook + Open-Meteo development fallback
- Groq/OpenAI-compatible LLM support
- FastAPI backend + React/Vite frontend

## Run

### Backend
```bash
cd backend
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env
uvicorn main:app --reload --port 8000
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173

## AI setup
Copy `.env.example` to `.env`.

For Groq:
- `LLM_PROVIDER=groq`
- `LLM_API_KEY=your_key`
- `LLM_MODEL=llama-3.3-70b-versatile`

For an OpenAI-compatible endpoint:
- `LLM_PROVIDER=openai_compatible`
- `LLM_BASE_URL=...`
- `LLM_API_KEY=...`
- `LLM_MODEL=...`

If no AI key is configured, WeatherGPT still works using a deterministic local response engine.

## IMD integration
The code contains an IMD adapter. Put the official IMD endpoint/token supplied to your SIH team into:
- `IMD_BASE_URL`
- `IMD_API_KEY`

Because IMD API access/endpoints can vary by authorization and service, the development fallback is Open-Meteo. Do not claim fallback data is IMD data in a competition demo.

## Architecture

Browser → FastAPI → Query Parser → Weather Provider → Risk Engine → LLM → Evidence-backed answer

For production/SIH integration, replace/augment the development weather provider with authorized IMD APIs and WIS2/CAP alert ingestion.
